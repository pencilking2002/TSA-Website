<?php
	/* for : class - _panel, method - main_builder. autobuild on : 26 December, 2011 08:34:13 */
	function cosmotheme__main( ){
		_panel::main_builder( 'cosmotheme__main' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function resources__custom__post( ){
		_panel::builder( 'resources__custom__post' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function resources__custom__sidebar( ){
		_panel::builder( 'resources__custom__sidebar' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__general__theme( ){
		_panel::builder( 'settings__general__theme' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__general__upload( ){
		_panel::builder( 'settings__general__upload' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__front_page__resource( ){
		_panel::builder( 'settings__front_page__resource' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__layout__style( ){
		_panel::builder( 'settings__layout__style' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__blogging__posts( ){
		_panel::builder( 'settings__blogging__posts' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__blogging__pages( ){
		_panel::builder( 'settings__blogging__pages' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__blogging__attachments( ){
		_panel::builder( 'settings__blogging__attachments' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__blogging__likes( ){
		_panel::builder( 'settings__blogging__likes' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__style__general( ){
		_panel::builder( 'settings__style__general' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__style__single( ){
		_panel::builder( 'settings__style__single' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__style__page( ){
		_panel::builder( 'settings__style__page' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__style__archive( ){
		_panel::builder( 'settings__style__archive' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__style__menu( ){
		_panel::builder( 'settings__style__menu' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__style__sidebars( ){
		_panel::builder( 'settings__style__sidebars' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__style__front_page_widgets( ){
		_panel::builder( 'settings__style__front_page_widgets' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__style__slideshow( ){
		_panel::builder( 'settings__style__slideshow' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__payment__paypal( ){
		_panel::builder( 'settings__payment__paypal' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__payment__check_transactions( ){
		_panel::builder( 'settings__payment__check_transactions' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function settings__slideshow__general( ){
		_panel::builder( 'settings__slideshow__general' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function extra__settings__css( ){
		_panel::builder( 'extra__settings__css' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function extra__settings__io( ){
		_panel::builder( 'extra__settings__io' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 26 December, 2011 11:36:04 */
	function extra__settings__notifications( ){
		_panel::builder( 'extra__settings__notifications' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 29 December, 2011 14:53:25 */
	function settings__menus__style( ){
		_panel::builder( 'settings__menus__style' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 29 December, 2011 15:06:39 */
	function settings__menus__menus( ){
		_panel::builder( 'settings__menus__menus' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 4 January, 2012 15:40:43 */
	function settings__blogging__archive( ){
		_panel::builder( 'settings__blogging__archive' );
	}
?>
<?php
	/* for : class - _panel, method - builder. autobuild on : 13 January, 2012 11:15:58 */
	function settings__social__facebook( ){
		_panel::builder( 'settings__social__facebook' );
	}
?>
