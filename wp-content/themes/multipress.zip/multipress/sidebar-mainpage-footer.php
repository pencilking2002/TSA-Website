<?php
if( dynamic_sidebar ( 'mainpage-footer' ) ){

}
?>