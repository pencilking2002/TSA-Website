<?php
	header('Content-type: text/css');

    _core::method( '_text' , 'load_fonts' );
    _core::method( '_text' , 'generic_style' );
    
	
?>

