<?php 

/*

Template Name: textile-events

*/

?>
<?php get_header(); ?>

	<div class="b_content clearfix" id="main">

		<div class="b_page clearfix">

			<div class="b_text">

				<!-- the tabs -->
				<ul class="tabs main">
					<li class = "event-cat-title">Event Categories</li>
					<li><a href="#1" class="w1 main" class="current">All Events</a></li>
					<li><a href="#1" class="w1 main" class="current">Exhibitions</a></li>
					<li><a href="#1" class="w1 main">Lectures</a></li>
					<li><a href="#1" class="w1 main">Tours</a></li>
				</ul>

				<!-- tab "panes" -->
				<div class="panes main">
					<div> 
						<ul class="tabs nested">
						      <li><a href="#2" class="nested w1">Upcoming Events</a></li>
						      <li><a href="#2" class="nested w1">Past Events</a></li>
					  </ul>

<!-- ******************************************************* BEGIN NESTED UPCOMING AND PAST EVENTS(cat 1 tab contents) **************************************************************** -->
								
								<div class="panes nested">
									<div class="all-upcoming-events"><!-- 1st nested tab contents for 'All Events' category--><!-- BEGIN ALL UPCOMING EVENTS -->
										
										<?php query_posts('event-type=upcoming'); ?><!--Only get posts in the 'upcoming' taxonomy-->
										<?php while ( have_posts() ) : the_post(); ?>
											<div class ="post"><!--Begin Post -->
												<div class ="img-cap">
													<p><?php the_post_thumbnail(); ?></p>
													<div>
														<?php /* the_field('event_type'); */ ?>
													</span><?php the_terms( $post->ID, 'event-category', '<span class="event-cat">','</span ><span class="event-cat">', '</span>' ); ?></span>
												</div>
											</div>

											<div class ="event-body"> 
												<h3><a href ="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
												<span><?php the_field('event_dates'); ?></span><br />
												</span><?php the_field('event_location'); ?></span><br />
												<p><?php the_content(); ?></p>
												</span><?php the_field('image_caption'); ?></span>
											</div><!--End Post -->	
									</div><!-- END TAB CONTENTS -->
							<?php endwhile; ?>

						</div><!-- END ALL UPCOMING EVENTS -->
	
	
						<div class="all-past-events"><!-- 2nd nested tab contents for 'All Events' category --><!-- BEGIN ALL PAST EVENTS -->
							
							<?php query_posts('event-type=past'); ?>
							<?php while ( have_posts() ) : the_post(); ?>
								<div class ="post"><!--Begin Post -->
									<div class ="img-cap">
										<p><?php the_post_thumbnail(); ?></p>
										<div>
											<?php /* the_field('event_type'); */ ?>
										</span><?php the_terms( $post->ID, 'event-category', '<span class="event-cat">','</span ><span class="event-cat">', '</span>' ); ?></span>
									</div>
								</div>

								<div class ="event-body"> 
									<h3><a href ="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
									<span><?php the_field('event_dates'); ?></span><br />
									</span><?php the_field('event_location'); ?></span><br />
									<p><?php the_content(); ?></p>
									</span><?php the_field('image_caption'); ?></span>
								</div><!--End Post -->	
						</div><!-- END TAB CONTENTS -->
							<?php endwhile; ?>

					</div><!-- END ALL PAST EVENTS -->
									
								
						    </div>
					</div><!-- End of nested tabs->
			
<!-- ******************************************************* END OF NESTED UPCOMING AND PAST EVENTS(cat 1 tab contents) **************************************************************** -->
			
					
			
					<div class="new panes nested">
						<div class="all-upcoming-events"><!-- 1st nested tab contents for 'All Events' category--><!-- BEGIN ALL UPCOMING EVENTS -->
							
							<?php query_posts('event-type=upcoming'); ?><!--Only get posts in the 'upcoming' taxonomy-->
							<?php while ( have_posts() ) : the_post(); ?>
								<div class ="post"><!--Begin Post -->
									<div class ="img-cap">
										<p><?php the_post_thumbnail(); ?></p>
										<div>
											<?php /* the_field('event_type'); */ ?>
										</span><?php the_terms( $post->ID, 'event-category', '<span class="event-cat">','</span ><span class="event-cat">', '</span>' ); ?></span>
									</div>
								</div>

								<div class ="event-body"> 
									<h3><a href ="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
									<span><?php the_field('event_dates'); ?></span><br />
									</span><?php the_field('event_location'); ?></span><br />
									<p><?php the_content(); ?></p>
									</span><?php the_field('image_caption'); ?></span>
								</div><!--End Post -->	
						</div><!-- END TAB CONTENTS -->
				<?php endwhile; ?>

			</div><!-- END ALL UPCOMING EVENTS -->


			<div class="all-past-events"><!-- 2nd nested tab contents for 'All Events' category --><!-- BEGIN ALL PAST EVENTS -->
				
				<?php query_posts('event-type=past'); ?>
				<?php while ( have_posts() ) : the_post(); ?>
					<div class ="post"><!--Begin Post -->
						<div class ="img-cap">
							<p><?php the_post_thumbnail(); ?></p>
							<div>
								<?php /* the_field('event_type'); */ ?>
							</span><?php the_terms( $post->ID, 'event-category', '<span class="event-cat">','</span ><span class="event-cat">', '</span>' ); ?></span>
						</div>
					</div>

					<div class ="event-body"> 
						<h3><a href ="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<span><?php the_field('event_dates'); ?></span><br />
						</span><?php the_field('event_location'); ?></span><br />
						<p><?php the_content(); ?></p>
						</span><?php the_field('image_caption'); ?></span>
					</div><!--End Post -->	
			</div><!-- END TAB CONTENTS -->
				<?php endwhile; ?>

		</div><!-- END ALL PAST EVENTS -->
						
					
			    </div>
		</div><!-- End of nested tabs-->
					
					<div>Third tab content</div>
				</div>


				                                  
					 </div>
			</div>
			
		</div>

	</div><!-- End Main -->
	<script>

	// perform JavaScript after the document is scriptable.
	jQuery(function() {
		// setup ul.tabs to work as tabs for each div directly under div.panes
		jQuery("ul.main.tabs").tabs("div.main.panes > div", {tabs: 'a.main'});

		jQuery("ul.nested.tabs").tabs("div.nested.panes > div", {tabs: 'a.nested'});
	});
	</script>
	
	<?php get_footer(); ?>