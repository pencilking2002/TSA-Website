<?php
if( dynamic_sidebar ( 'footer-second' ) ){

}
?>