<?php
if( dynamic_sidebar ( 'social-media' ) ){

}
?>