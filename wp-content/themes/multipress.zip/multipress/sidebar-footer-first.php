<?php
if( dynamic_sidebar ( 'footer-first' ) ){

}
?>