<?php
if( dynamic_sidebar ( 'whitey' ) ){

}
?>