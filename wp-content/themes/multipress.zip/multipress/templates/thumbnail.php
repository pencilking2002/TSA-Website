<?php
    /* thumbnail  grid , list | full , no-full | mising , nsfw  */
    _core::hook( 'thumbnail' )
?>