<article id="post-<?php the_ID(); ?>">
    <!-- thumbnail -->
    <h1> <?php /* title */ ?> </h1>
    <!-- meta -->
    <!-- content -->
    <?php _core::hook( 'grid' ); ?>
</article>