<!-- template for favicon use by default icon if not is set in settings -> styling -->
<?php _core::hook( 'favicon' ); ?>